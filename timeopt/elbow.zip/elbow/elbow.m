%***************************************************************************
%  tag: Diederik Verscheure  di jun 12 18:12:36 CEST 2007  elbow.m
%
%                           elbow.m -  description
%                           ----------------------------
%    begin                : di juni 12 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Tests the time-optimal trajectory planning algorithm
% for a 3-DOF elbow manipulator.
%
% Data and robot model based on:
% Pfeiffer, F. & Johanni, R.,
% A Concept for Manipulator Trajectory Planning,
% IEEE Journal of Robotics and Automation, 1987, RA-3, 115-123
%
% Angles q2 and q3 are positive in downward direction (negative Y).
% To obtain convention of Pfeiffer-Johanni, multiply q2 and q3 with -1.
% 
% ***************************************************************************

clear all;
close all;
global savefigs;
% When set to 1, this will save all images in "./images/" directory
savefigs = 0;

% Use mosek, csdp, sdpt3, sedumi
% Tested with mosek/csdp/sdpt3/sedumi so far.
solver = 'mosek';
solver = 'csdp';
solver = 'sdpt3';
solver = 'sedumi';
    
% Number of grid points
sgrid = 200;

% Torque lower and upper bounds
torquelb = -[140;140;50];
torqueub = [140;140;50];
nrdof = size(torquelb,1);


% Weighting for integral of torque squared
gamma1 = 0;
% Weighting for integral of absolute value of the torque rate of change
gamma2 = 1e-6;

% The path function
pathfun = @parapath;
pathfun = @circlepath;

% The manipulator dynamics
invdynfun = @invdynelbow;

% Fetch all path-dependent quantities
coulomb = 0;
[s, sm, ds, q, qp, qpp, Mv, Cv, gv] = dynpathparams(invdynfun, pathfun, sgrid);

% Solve the time-optimal trajectory planning problem
% ---------------------------------------
% Basic version
% [a, b, c, d, tau, bvar, cvar, dvar, tauvar, F, t, diagnostics] = timeoptpathconstr(s, sm, ds, q, qp, qpp, Mv, Cv, gv, torquelb, torqueub, gamma1, gamma2, solver);
% ---------------------------------------
% Optimized version with torques eliminated as optimization variables
% [a, b, c, d, tau, bvar, cvar, dvar, F, t, diagnostics] = timeoptpathconstropt(s, sm, ds, q, qp, qpp, Mv, Cv, gv, torquelb, torqueub, gamma1, gamma2, solver);
% ---------------------------------------
% Optimized version with torques eliminated as optimization variables which does not use YALMIP
[a, b, c, d, tau, t, diagnostics] = timeoptpathconstrsed(s, sm, ds, q, qp, qpp, Mv, Cv, gv, torquelb, torqueub, gamma1, gamma2, solver);
% ---------------------------------------

% Obtain the time vector
t = cumsum(2*ds./(sqrt(b(2:end))+sqrt(b(1:end-1))));
bm = (b(2:end)+b(1:end-1))/2;
qdot = repmat(sqrt(bm),3,1).*qp;
qddot = repmat(a,3,1).*qp + repmat(bm,3,1).*qpp;

% Conversion to Pfeiffer-Johanni convention
tau(2,:) = -tau(2,:);
tau(3,:) = -tau(3,:);

q(2,:) = -q(2,:);
q(3,:) = -q(3,:);

qdot(2,:) = -qdot(2,:);
qdot(3,:) = -qdot(3,:);

qddot(2,:) = -qddot(2,:);
qddot(3,:) = -qddot(3,:);

% Plot figures
figure
lh = plot(t,tau(1,:),'b',t,tau(2,:),'g-.',t,tau(3,:),'k--'); set(lh(2),'color',get(lh(2),'color')*0.4);
setunits('s','nm');
title('Joint torques')
legend('joint torque 1','joint torque 2','joint torque 3','location','SouthEast');
setfigtempl;
as = axis;
axis([as(1) as(2) -150 150]);
savepls(gcf,sprintf('elbow_torquetime_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2*100));

figure
lh = plot(sm,tau(1,:),'b',sm,tau(2,:),'g-.',sm,tau(3,:),'k--'); set(lh(2),'color',get(lh(2),'color')*0.4);
setunits('s','nm');
xlabel('path coordinate (-)')
title('Joint torques')
legend('joint torque 1','joint torque 2','joint torque 3','location','SouthEast');
setfigtempl;
as = axis;
axis([as(1) as(2) -150 150]);
set(gcf,'position',[175 188 853 428]);
savepls(gcf,sprintf('elbow_torquepath_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2*100));

figure
plot(t,sm);
title('Path coordinate - time relation');
xlabel('time (s)');
ylabel('path coordinate s (-)');
setfigtempl;
savepls(gcf,sprintf('elbow_pathtime_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2*100));

figure
lh = plot(t,q(1,:),'b',t,q(2,:),'g-.',t,q(3,:),'k--'); set(lh(2),'color',get(lh(2),'color')*0.4);
xlabel('time (s)')
ylabel('joint angle (rad)')
title('Joint angles')
legend('joint angle 1','joint angle 2','joint angle 3','location','SouthEast');
setfigtempl;
savepls(gcf,sprintf('elbow_jointtime_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2*100));

figure
lh = plot(t,qdot(1,:),'b',t,qdot(2,:),'g-.',t,qdot(3,:),'k--'); set(lh(2),'color',get(lh(2),'color')*0.4);
xlabel('time (s)')
ylabel('joint velocity (rad)')
title('Joint velocities')
legend('joint velocity 1','joint velocity 2','joint velocity 3','location','SouthEast');
setfigtempl;
savepls(gcf,sprintf('elbow_jointveltime_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2*100));

figure
plot(s,sqrt(b));
xlabel('path coordinate (-)');
ylabel('pseudo velocity (1/s)');
title('Pseudo velocity');
setfigtempl;
as = axis;
axis([as(1) as(2) as(3) as(4)*1.05]);
savepls(gcf,sprintf('elbow_pseudovelpath_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2*100));

figure
plot(sm,a);
xlabel('path coordinate (-)')
ylabel('pseudo acceleration (1/s^2)');
title('Pseudo acceleration');
setfigtempl;
as = axis;
axis([as(1) as(2) as(3)*1.05 as(4)*1.05]);
savepls(gcf,sprintf('elbow_pseudoaccpath_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2*100));


