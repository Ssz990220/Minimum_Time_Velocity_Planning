function [M,C,g] = invdynelbow(q,qdot)
%***************************************************************************
%  tag: Diederik Verscheure  di jun 12 17:39:03 CEST 2007  invdynelbow.m
%
%                           invdynelbow.m -  description
%                           ----------------------------
%    begin                : di juni 12 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Inverse dynamic model of a 3-DOF elbow manipulator.
%
% Data and robot model based on:
% Pfeiffer, F. & Johanni, R.,
% A Concept for Manipulator Trajectory Planning,
% IEEE Journal of Robotics and Automation, 1987, RA-3, 115-123
%
% Angles q2 and q3 are positive in downward direction (negative Y).
% To obtain convention of Pfeiffer-Johanni, multiply q2 and q3 with -1.
% 
% ***************************************************************************

[Jl1,Jl2,Jl3,Jt2,Jt3,m2,m3,l1,l2,l3,r2,r3] = elbowparams;
gg = 9.81;

M = zeros(3,3,size(q,2));
C = zeros(3,3,size(q,2));
g = zeros(3,size(q,2));

fprintf('Generating dynamic model matrices...\n');
for k = 1:size(q,2)
	q1 = q(1,k);
	q2 = q(2,k);
	q3 = q(3,k);

	qdot1 = qdot(1,k);
	qdot2 = qdot(2,k);
	qdot3 = qdot(3,k);

	bm11 = Jl1+Jt2*cos(q2)^2+Jl2*(1-cos(q2)^2)+Jt3*cos(q2+q3)^2+Jl3*(1-cos(q2+q3)^2)+m2*(l1+r2*cos(q2))^2+m3*(l1+l2*cos(q2)+r3*cos(q2+q3))^2;
	bm12 = 0;
	bm13 = 0;
	bm21 = 0;
	bm22 = Jt2+r2^2*m2+Jt3+m3*(l2^2+r3^2+2*l2*r3*cos(q3));
	bm23 = Jt3+m3*(r3^2+l2*r3*cos(q3));
	bm31 = 0;
	bm32 = Jt3+m3*(r3^2+l2*r3*cos(q3));
	bm33 = Jt3+r3^2*m3;

	M(1,1,k) = bm11;
	M(1,2,k) = bm12;
	M(1,3,k) = bm13;
	M(2,1,k) = bm21;
	M(2,2,k) = bm22;
	M(2,3,k) = bm23;
	M(3,1,k) = bm31;
	M(3,2,k) = bm32;
	M(3,3,k) = bm33;

	c111 = 0;
	c112 = -Jt2*cos(q2)*sin(q2)+Jl2*cos(q2)*sin(q2)-Jt3*cos(q2+q3)*sin(q2+q3)+Jl3*cos(q2+q3)*sin(q2+q3)-m2*(l1+r2*cos(q2))*r2*sin(q2)+m3*(l1+l2*cos(q2)+r3*cos(q2+q3))*(-l2*sin(q2)-r3*sin(q2+q3));
	c113 = -Jt3*cos(q2+q3)*sin(q2+q3)+Jl3*cos(q2+q3)*sin(q2+q3)-m3*(l1+l2*cos(q2)+r3*cos(q2+q3))*r3*sin(q2+q3);
	c121 = -Jt2*cos(q2)*sin(q2)+Jl2*cos(q2)*sin(q2)-Jt3*cos(q2+q3)*sin(q2+q3)+Jl3*cos(q2+q3)*sin(q2+q3)-m2*(l1+r2*cos(q2))*r2*sin(q2)+m3*(l1+l2*cos(q2)+r3*cos(q2+q3))*(-l2*sin(q2)-r3*sin(q2+q3));
	c122 = 0;
	c123 = 0;
	c131 = -Jt3*cos(q2+q3)*sin(q2+q3)+Jl3*cos(q2+q3)*sin(q2+q3)-m3*(l1+l2*cos(q2)+r3*cos(q2+q3))*r3*sin(q2+q3);
	c132 = 0;
	c133 = 0;
	c211 = Jt2*cos(q2)*sin(q2)-Jl2*cos(q2)*sin(q2)+Jt3*cos(q2+q3)*sin(q2+q3)-Jl3*cos(q2+q3)*sin(q2+q3)+m2*(l1+r2*cos(q2))*r2*sin(q2)-m3*(l1+l2*cos(q2)+r3*cos(q2+q3))*(-l2*sin(q2)-r3*sin(q2+q3));
	c212 = 0;
	c213 = 0;
	c221 = 0;
	c222 = 0;
	c223 = -m3*l2*r3*sin(q3);
	c231 = 0;
	c232 = -m3*l2*r3*sin(q3);
	c233 = -m3*l2*r3*sin(q3);
	c311 = Jt3*cos(q2+q3)*sin(q2+q3)-Jl3*cos(q2+q3)*sin(q2+q3)+m3*(l1+l2*cos(q2)+r3*cos(q2+q3))*r3*sin(q2+q3);
	c312 = 0;
	c313 = 0;
	c321 = 0;
	c322 = m3*l2*r3*sin(q3);
	c323 = 0;
	c331 = 0;
	c332 = 0;
	c333 = 0;

	cm11 = c111*qdot1+c112*qdot2+c113*qdot3;
	cm12 = c121*qdot1+c122*qdot2+c123*qdot3;
	cm13 = c131*qdot1+c132*qdot2+c133*qdot3;
	cm21 = c211*qdot1+c212*qdot2+c213*qdot3;
	cm22 = c221*qdot1+c222*qdot2+c223*qdot3;
	cm23 = c231*qdot1+c232*qdot2+c233*qdot3;
	cm31 = c311*qdot1+c312*qdot2+c313*qdot3;
	cm32 = c321*qdot1+c322*qdot2+c323*qdot3;
	cm33 = c331*qdot1+c332*qdot2+c333*qdot3;

	C(1,1,k) = cm11;
	C(1,2,k) = cm12;
	C(1,3,k) = cm13;
	C(2,1,k) = cm21;
	C(2,2,k) = cm22;
	C(2,3,k) = cm23;
	C(3,1,k) = cm31;
	C(3,2,k) = cm32;
	C(3,3,k) = cm33;

	g1 = 0;
	g2 = -(gg*(m2*r2+m3*l2)*cos(q2)+gg*m3*r3*cos(q2+q3));
	g3 = -(gg*m3*r3*cos(q2+q3));

	g(1,k) = g1;
	g(2,k) = g2;
	g(3,k) = g3;
end
fprintf('Done generating dynamic model matrices...\n');

