function [q1,q2,q3] = invkinelbow(xees,yees,zees,nsol3)
%***************************************************************************
%  tag: Diederik Verscheure  wo jul  4 09:51:30 CEST 2007  invkinelbow.m
%
%                           invkinelbow.m -  description
%                           ----------------------------
%    begin                : wo juli 04 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Inverse kinematics for a 3-DOF elbow manipulator.
%
% Data and robot model based on:
% Pfeiffer, F. & Johanni, R.,
% A Concept for Manipulator Trajectory Planning,
% IEEE Journal of Robotics and Automation, 1987, RA-3, 115-123
%
% Angles q2 and q3 are positive in downward direction (negative Y).
% To obtain convention of Pfeiffer-Johanni, multiply q2 and q3 with -1.
% 
% Note: this has only been tested with the trajectories found in Pfeiffer-Johanni
% 
% ***************************************************************************

[Jl1,Jl2,Jl3,Jt2,Jt3,m2,m3,l1,l2,l3,r2,r3] = elbowparams;
q1 = zeros(size(xees));
q2 = zeros(size(xees));
q3 = zeros(size(xees));

for k = 1:length(xees)
	q1(k) = -atan2(zees(k),xees(k));
	% Take negative solution
	cosq3 = ((xees(k)-l1*cos(q1(k)))^2+(zees(k)+l1*sin(q1(k)))^2+yees(k)^2-l2^2-l3^2)/(2*l3*l2);
	if cosq3 > 1
		[xees(k) yees(k) zees(k)]
		q1(k)
		fprintf('Unreachable position...\n');
		pause
	end
	if nsol3 == 1
		sinq3 = -sqrt(1-cosq3^2);
	else
		sinq3 = sqrt(1-cosq3^2);
	end
	q3(k) = atan2(sinq3,cosq3);
	if q3(k) ~= 0
		q21 = atan2((l3 * (-l1 * l2 - sin(q1(k)) * zees(k) * l2 + l2 * xees(k) * cos(q1(k)) - l3 * cos(q3(k)) * zees(k) * sin(q1(k)) + l3 * cos(q3(k)) * xees(k) * cos(q1(k)) - l3 * cos(q3(k)) * l1 + sqrt(l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + 0.2e1 * l3 ^ 3 * cos(q3(k)) * l2 * sin(q3(k)) ^ 2 - 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 + 0.2e1 * l3 ^ 2 * l1 * xees(k) * cos(q1(k)) - 0.2e1 * l3 ^ 2 * l1 * zees(k) * sin(q1(k)) + l2 ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * l1 ^ 2 + l2 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + l2 ^ 2 * l3 ^ 2 * sin(q3(k)) ^ 2 - l3 ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 - l2 ^ 2 * xees(k) ^ 2 + l3 ^ 4 * sin(q3(k)) ^ 2 - l3 ^ 2 * l1 ^ 2 + 0.2e1 * l2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 * l3 * cos(q3(k)) - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * xees(k) * cos(q1(k)) + 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * l1 - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) * cos(q1(k)) * l1 + 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + 0.2e1 * l3 ^ 2 * xees(k) * cos(q1(k)) * zees(k) * sin(q1(k)) - l3 ^ 2 * xees(k) ^ 2)) / (l2 ^ 2 + 0.2e1 * l3 * cos(q3(k)) * l2 + l3 ^ 2) * cos(q3(k)) + l2 * (-l1 * l2 - sin(q1(k)) * zees(k) * l2 + l2 * xees(k) * cos(q1(k)) - l3 * cos(q3(k)) * zees(k) * sin(q1(k)) + l3 * cos(q3(k)) * xees(k) * cos(q1(k)) - l3 * cos(q3(k)) * l1 + sqrt(l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + 0.2e1 * l3 ^ 3 * cos(q3(k)) * l2 * sin(q3(k)) ^ 2 - 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 + 0.2e1 * l3 ^ 2 * l1 * xees(k) * cos(q1(k)) - 0.2e1 * l3 ^ 2 * l1 * zees(k) * sin(q1(k)) + l2 ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * l1 ^ 2 + l2 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + l2 ^ 2 * l3 ^ 2 * sin(q3(k)) ^ 2 - l3 ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 - l2 ^ 2 * xees(k) ^ 2 + l3 ^ 4 * sin(q3(k)) ^ 2 - l3 ^ 2 * l1 ^ 2 + 0.2e1 * l2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 * l3 * cos(q3(k)) - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * xees(k) * cos(q1(k)) + 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * l1 - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) * cos(q1(k)) * l1 + 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + 0.2e1 * l3 ^ 2 * xees(k) * cos(q1(k)) * zees(k) * sin(q1(k)) - l3 ^ 2 * xees(k) ^ 2)) / (l2 ^ 2 + 0.2e1 * l3 * cos(q3(k)) * l2 + l3 ^ 2) + l1 - xees(k) * cos(q1(k)) + zees(k) * sin(q1(k))) / l3 / sin(q3(k)), (-l1 * l2 - sin(q1(k)) * zees(k) * l2 + l2 * xees(k) * cos(q1(k)) - l3 * cos(q3(k)) * zees(k) * sin(q1(k)) + l3 * cos(q3(k)) * xees(k) * cos(q1(k)) - l3 * cos(q3(k)) * l1 + sqrt(l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + 0.2e1 * l3 ^ 3 * cos(q3(k)) * l2 * sin(q3(k)) ^ 2 - 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 + 0.2e1 * l3 ^ 2 * l1 * xees(k) * cos(q1(k)) - 0.2e1 * l3 ^ 2 * l1 * zees(k) * sin(q1(k)) + l2 ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * l1 ^ 2 + l2 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + l2 ^ 2 * l3 ^ 2 * sin(q3(k)) ^ 2 - l3 ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 - l2 ^ 2 * xees(k) ^ 2 + l3 ^ 4 * sin(q3(k)) ^ 2 - l3 ^ 2 * l1 ^ 2 + 0.2e1 * l2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 * l3 * cos(q3(k)) - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * xees(k) * cos(q1(k)) + 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * l1 - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) * cos(q1(k)) * l1 + 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + 0.2e1 * l3 ^ 2 * xees(k) * cos(q1(k)) * zees(k) * sin(q1(k)) - l3 ^ 2 * xees(k) ^ 2)) / (l2 ^ 2 + 0.2e1 * l3 * cos(q3(k)) * l2 + l3 ^ 2));
		q22 = atan2((-l3 * (l1 * l2 + sin(q1(k)) * zees(k) * l2 - l2 * xees(k) * cos(q1(k)) + l3 * cos(q3(k)) * zees(k) * sin(q1(k)) - l3 * cos(q3(k)) * xees(k) * cos(q1(k)) + l3 * cos(q3(k)) * l1 + sqrt(l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + 0.2e1 * l3 ^ 3 * cos(q3(k)) * l2 * sin(q3(k)) ^ 2 - 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 + 0.2e1 * l3 ^ 2 * l1 * xees(k) * cos(q1(k)) - 0.2e1 * l3 ^ 2 * l1 * zees(k) * sin(q1(k)) + l2 ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * l1 ^ 2 + l2 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + l2 ^ 2 * l3 ^ 2 * sin(q3(k)) ^ 2 - l3 ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 - l2 ^ 2 * xees(k) ^ 2 + l3 ^ 4 * sin(q3(k)) ^ 2 - l3 ^ 2 * l1 ^ 2 + 0.2e1 * l2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 * l3 * cos(q3(k)) - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * xees(k) * cos(q1(k)) + 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * l1 - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) * cos(q1(k)) * l1 + 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + 0.2e1 * l3 ^ 2 * xees(k) * cos(q1(k)) * zees(k) * sin(q1(k)) - l3 ^ 2 * xees(k) ^ 2)) / (l2 ^ 2 + 0.2e1 * l3 * cos(q3(k)) * l2 + l3 ^ 2) * cos(q3(k)) - l2 * (l1 * l2 + sin(q1(k)) * zees(k) * l2 - l2 * xees(k) * cos(q1(k)) + l3 * cos(q3(k)) * zees(k) * sin(q1(k)) - l3 * cos(q3(k)) * xees(k) * cos(q1(k)) + l3 * cos(q3(k)) * l1 + sqrt(l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + 0.2e1 * l3 ^ 3 * cos(q3(k)) * l2 * sin(q3(k)) ^ 2 - 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 + 0.2e1 * l3 ^ 2 * l1 * xees(k) * cos(q1(k)) - 0.2e1 * l3 ^ 2 * l1 * zees(k) * sin(q1(k)) + l2 ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * l1 ^ 2 + l2 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + l2 ^ 2 * l3 ^ 2 * sin(q3(k)) ^ 2 - l3 ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 - l2 ^ 2 * xees(k) ^ 2 + l3 ^ 4 * sin(q3(k)) ^ 2 - l3 ^ 2 * l1 ^ 2 + 0.2e1 * l2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 * l3 * cos(q3(k)) - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * xees(k) * cos(q1(k)) + 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * l1 - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) * cos(q1(k)) * l1 + 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + 0.2e1 * l3 ^ 2 * xees(k) * cos(q1(k)) * zees(k) * sin(q1(k)) - l3 ^ 2 * xees(k) ^ 2)) / (l2 ^ 2 + 0.2e1 * l3 * cos(q3(k)) * l2 + l3 ^ 2) + l1 - xees(k) * cos(q1(k)) + zees(k) * sin(q1(k))) / l3 / sin(q3(k)), -(l1 * l2 + sin(q1(k)) * zees(k) * l2 - l2 * xees(k) * cos(q1(k)) + l3 * cos(q3(k)) * zees(k) * sin(q1(k)) - l3 * cos(q3(k)) * xees(k) * cos(q1(k)) + l3 * cos(q3(k)) * l1 + sqrt(l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + 0.2e1 * l3 ^ 3 * cos(q3(k)) * l2 * sin(q3(k)) ^ 2 - 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 + 0.2e1 * l3 ^ 2 * l1 * xees(k) * cos(q1(k)) - 0.2e1 * l3 ^ 2 * l1 * zees(k) * sin(q1(k)) + l2 ^ 2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 + l3 ^ 2 * cos(q3(k)) ^ 2 * l1 ^ 2 + l2 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + l2 ^ 2 * l3 ^ 2 * sin(q3(k)) ^ 2 - l3 ^ 2 * zees(k) ^ 2 * sin(q1(k)) ^ 2 + l3 ^ 2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 - l2 ^ 2 * xees(k) ^ 2 + l3 ^ 4 * sin(q3(k)) ^ 2 - l3 ^ 2 * l1 ^ 2 + 0.2e1 * l2 * xees(k) ^ 2 * cos(q1(k)) ^ 2 * l3 * cos(q3(k)) - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * xees(k) * cos(q1(k)) + 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * zees(k) * sin(q1(k)) * l1 - 0.2e1 * l3 ^ 2 * cos(q3(k)) ^ 2 * xees(k) * cos(q1(k)) * l1 + 0.2e1 * l3 * cos(q3(k)) * l2 * xees(k) ^ 2 * sin(q1(k)) ^ 2 + 0.2e1 * l3 ^ 2 * xees(k) * cos(q1(k)) * zees(k) * sin(q1(k)) - l3 ^ 2 * xees(k) ^ 2)) / (l2 ^ 2 + 0.2e1 * l3 * cos(q3(k)) * l2 + l3 ^ 2));
	else
		q21 = pi - acos((l1 - xees * cos(q1) + zees * sin(q1)) / (l3 + l2));
		q22 = q21;
	end
	if sign(yees(k)) == sign(-l3*sin(q21+q3(k))-l2*sin(q21))
		q2(k) = q21;
	else
		q2(k) = q22;
	end

	% Sanity check
	[xeet,yeet,zeet]=fwkinelbow(q1(k),q2(k),q3(k));
	if sum(abs([xeet-xees(k) yeet-yees(k) zeet-zees(k)])) > 1e-7
		sum(abs([xeet-xees(k) yeet-yees(k) zeet-zees(k)]))
		[xees(k) yees(k) zees(k)]
		[xeet yeet zeet]
		[q1(k) q2(k) q3(k)]
		fprintf('Wrong inverse kinematics...\n');
		pause
	end
end
	


