***************************************************************************
  tag: Diederik Verscheure  vr aug 31 07:10:07 CEST 2007  phd/projects/time_optimal_trajectory/matlab

                           phd/projects/time_optimal_trajectory/matlab -  description
                           ----------------------------
    begin                : vr augustus 31 2007
    copyright            : (C) 2007 K.U.Leuven
    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be

***************************************************************************
Purpose
---------------------------------------------------------------------------

The following set of matlab files calculates the time-optimal trajectory
along the given path for the 3-DOF elbow manipulator found in:
Pfeiffer, F. & Johanni, R.,
A Concept for Manipulator Trajectory Planning,
IEEE Journal of Robotics and Automation, 1987, RA-3, 115-123

Note that angles q2 and q3 are positive in downward direction (negative Y).
To obtain convention of Pfeiffer-Johanni, multiply q2 and q3 with -1.

Getting started
---------------
- Make sure all requirements are installed (see below).
- Start up Matlab and go to the directory where this archive was unpacked.
- Type 'elbow' to start the trajectory calculation.
- The type of path and a number of options can be changed in elbow.m by commenting/uncommenting
  the appropriate lines.


Contents:
---------
elbow.m -- main file.
elbowparams.m -- definition of parameters.
fwkinelbow.m -- forward kinematics.
invkinelbow.m -- inverse kinematics.
invdynelbow.m -- inverse dynamic model.
parapathcart.m -- parabola path in operational space coordinates.
circlepathcart.m -- circle path in operational space coordinates.
parapath.m -- parabola path in joint space coordinates.
circlepath.m  -- circle path in joint space coordinates.
timeoptpathconstr.m -- implementation of the trajectory planning algorithm with torques as variables.
timeoptpathconstropt.m -- faster implementation of the trajectory planning algorithm with torques eliminated.
timeoptpathconstrsed.m -- faster implementation of the trajectory planning algorithm with torques eliminated
                          which does not use YALMIP.
dynpathparams.m -- calculates all path-dependent quantities which are passed to timeoptpathconstr*.m.
setunits.m -- general purpose. Sets units on figures.
setfigtempl.m -- general purpose. Sets line width and font sizes.
savepls.m -- general purpose. Saves figures.
savefig.m -- general purpose. Saves figures.

Requirements:
-------------
YALMIP - http://www.control.isy.liu.se/~johanl
SeDuMi - http://sedumi.mcmaster.ca/

Changes:
--------
20/10/08 - Can be used without YALMIP.
18/04/08 - Removed dependency on Spline toolbox.

***************************************************************************


