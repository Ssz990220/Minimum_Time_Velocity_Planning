function [q,qp,qpp]=circlepath(s)
%***************************************************************************
%  tag: Diederik Verscheure  wo jul  4 10:13:23 CEST 2007  circlepath.m
%
%                           circlepath.m -  description
%                           ----------------------------
%    begin                : wo juli 04 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Generates q,q',q'' for the circle path.
%
% Data and robot model based on:
% Pfeiffer, F. & Johanni, R.,
% A Concept for Manipulator Trajectory Planning,
% IEEE Journal of Robotics and Automation, 1987, RA-3, 115-123
%
% Angles q2 and q3 are positive in downward direction (negative Y).
% To obtain convention of Pfeiffer-Johanni, multiply q2 and q3 with -1.
% 
% ***************************************************************************

[xees,yees,zees]=circlepathcart(s);

fprintf('Generating joint-space trajectory...\n');
[q1,q2,q3]=invkinelbow(xees,yees,zees,0);

wlength = 5;
for m = 1:3
        eval(sprintf('q%dt = zeros(size(s));',m));
        eval(sprintf('qp%dt = zeros(size(s));',m));
        eval(sprintf('qpp%dt = zeros(size(s));',m));

        l = 1;
        for k = 1:(length(s)-1)
                eval(sprintf('B = q%d(1,k:min(k+wlength,length(s)))'';',m));
                sk = s(1,k:min(k+wlength,length(s)))';
                A = [sk.^2 sk ones(size(sk))];
                x = mldivide(A,B);
                while ((l <= length(s)) & (s(l) <= s(k+1)))
                        eval(sprintf('q%dt(l) = [s(l)^2 s(l) 1]*x;',m));
                        eval(sprintf('qp%dt(l) = [2*s(l) 1]*x(1:2);',m));
                        eval(sprintf('qpp%dt(l) = 2*x(1);',m));
                        l = l + 1;
                end
        end
end
q = [q1t;q2t;q3t];
qp = [qp1t;qp2t;qp3t];
qpp = [qpp1t;qpp2t;qpp3t];
fprintf('Done generating joint-space trajectory...\n');


