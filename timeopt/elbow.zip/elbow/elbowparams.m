function [Jl1,Jl2,Jl3,Jt2,Jt3,m2,m3,l1,l2,l3,r2,r3] = elbowparams()
%***************************************************************************
%  tag: Diederik Verscheure  wo jul  4 09:24:48 CEST 2007  elbowparams.m
%
%                           elbowparams.m -  description
%                           ----------------------------
%    begin                : wo juli 04 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Returns parameters of a 3-DOF elbow manipulator.
%
% Data and robot model based on:
% Pfeiffer, F. & Johanni, R.,
% A Concept for Manipulator Trajectory Planning,
% IEEE Journal of Robotics and Automation, 1987, RA-3, 115-123
% 
% ***************************************************************************

Jl1 = 5;
Jl2 = 0.1;
Jl3 = 0.02;
Jt2 = 0.6;
Jt3 = 0.3;
m2 = 6.6;
m3 = 4.2;
l1 = 0.1;
l2 = 0.75;
l3 = 0.75;
r2 = 0.55;
r3 = 0.6;

