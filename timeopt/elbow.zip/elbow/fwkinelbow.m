function [xees,yees,zees] = fwkinelbow(q1,q2,q3)
%***************************************************************************
%  tag: Diederik Verscheure  wo jul  4 09:51:30 CEST 2007  fwkinelbow.m
%
%                           fwkinelbow.m -  description
%                           ----------------------------
%    begin                : wo juli 04 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Forward kinematics for a 3-DOF elbow manipulator.
%
% Data and robot model based on:
% Pfeiffer, F. & Johanni, R.,
% A Concept for Manipulator Trajectory Planning,
% IEEE Journal of Robotics and Automation, 1987, RA-3, 115-123
%
% Angles q2 and q3 are positive in downward direction (negative Y).
% To obtain convention of Pfeiffer-Johanni, multiply q2 and q3 with -1.
% 
% ***************************************************************************

[Jl1,Jl2,Jl3,Jt2,Jt3,m2,m3,l1,l2,l3,r2,r3] = elbowparams;
xees = zeros(size(q1));
yees = zeros(size(q1));
zees = zeros(size(q1));

for k = 1:length(q1)
	xees(k) = (l3*cos(q2(k)+q3(k))+l2*cos(q2(k))+l1)*cos(q1(k));
	yees(k) = -l3*sin(q2(k)+q3(k))-l2*sin(q2(k));
	zees(k) = -(l3*cos(q2(k)+q3(k))+l2*cos(q2(k))+l1)*sin(q1(k));
end
	


