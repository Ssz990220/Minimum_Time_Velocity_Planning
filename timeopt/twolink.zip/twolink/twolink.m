%***************************************************************************
%  tag: Diederik Verscheure  di jun 12 18:12:36 CEST 2007  twolink.m
%
%                           twolink.m -  description
%                           ----------------------------
%    begin                : di juni 12 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Tests the time-optimal path-constrained optimal control problem for a 2 link manipulator.
% 
% ***************************************************************************

clear all;
close all;
global savefigs;
% When set to 1, this will save all images in "./images/" directory
savefigs = 0;

% Use mosek, csdp, sdpt3, sedumi
% Tested with mosek/csdp/sdpt3/sedumi so far.
solver = 'mosek';
solver = 'csdp';
solver = 'sdpt3';
solver = 'sedumi';

% Number of grid points    
sgrid = 500;

% Torque lower and upper bounds
torquelb = -[1;1];
torqueub = [1;1];

nrdof = size(torquelb,1);

% Weighting for integral of torque squared
gamma1 = 0;
% Weighting for integral of absolute value of the torque rate of change
gamma2 = [0 1e-3];

% The path function
pathfun = @singarcpath;

% The manipulator dynamics
invdynfun = @invdyntwolink;

% Fetch all path-dependent quantities
[s, sm, ds, q, qp, qpp, Mv, Cv, gv] = dynpathparams(invdynfun, pathfun, sgrid);


for k = 1:length(gamma2)
	
	% Solve the time-optimal trajectory planning problem
	% ---------------------------------------
	% Basic version
	% [a, b, c, d, tau, bvar, cvar, dvar, tauvar, F, t, diagnostics] = timeoptpathconstr(s, sm, ds, q, qp, qpp, Mv, Cv, gv, torquelb, torqueub, gamma1, gamma2(k), solver);
	% ---------------------------------------
	% Optimized version with torques eliminated as optimization variables
	% [a, b, c, d, tau, bvar, cvar, dvar, F, t, diagnostics] = timeoptpathconstropt(s, sm, ds, q, qp, qpp, Mv, Cv, gv, torquelb, torqueub, gamma1, gamma2(k), solver);
	% ---------------------------------------
	% Optimized version with torques eliminated as optimization variables which does not use YALMIP
	[a, b, c, d, tau, t, diagnostics] = timeoptpathconstrsed(s, sm, ds, q, qp, qpp, Mv, Cv, gv, torquelb, torqueub, gamma1, gamma2(k), solver);
	% ---------------------------------------
	
	% Obtain the time vector
	t = cumsum(2*ds./(sqrt(b(2:end))+sqrt(b(1:end-1))));
	bm = (b(2:end)+b(1:end-1))/2;
	qdot = repmat(sqrt(bm),2,1).*qp;
	qddot = repmat(a,2,1).*qp + repmat(bm,2,1).*qpp;
	
	figure
	lh = plot(t,tau(1,:),'b',t,tau(2,:),'g-.'); set(lh(2),'color',get(lh(2),'color')*0.4);
	setunits('s','nm');
	title('Joint torques')
	legend('joint torque 1','joint torque 2','location','NorthEast');
	setfigtempl;
	as = axis;
	axis([as(1) as(2) -1.05 1.05]);
	savepls(gcf,sprintf('twolink_torquetime_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2(k)*100));
	
	figure
	lh = plot(sm,tau(1,:),'b',sm,tau(2,:),'g-.'); set(lh(2),'color',get(lh(2),'color')*0.4);
	setunits('s','nm');
	xlabel('path coordinate (-)')
	title('Joint torques')
	legend('joint torque 1','joint torque 2','location','NorthEast');
	setfigtempl;
	as = axis;
	axis([as(1) as(2) -1.05 1.05]);
	savepls(gcf,sprintf('twolink_torquepath_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2(k)*100));
	
	figure
	plot(t,sm);
	title('Path coordinate - time relation');
	xlabel('time (s)');
	ylabel('path coordinate s (-)');
	setfigtempl;
	savepls(gcf,sprintf('twolink_pathtime_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2(k)*100));
	
	figure
	lh = plot(t,q(1,:),'b',t,q(2,:),'g-.'); set(lh(2),'color',get(lh(2),'color')*0.4);
	xlabel('time (s)')
	ylabel('joint angle (rad)')
	title('Joint angles')
	legend('joint angle 1','joint angle 2','location','NorthEast');
	setfigtempl;
	savepls(gcf,sprintf('twolink_jointtime_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2(k)*100));
	
	figure
	plot(s,sqrt(b));
	xlabel('path coordinate (-)');
	ylabel('pseudo velocity (1/s)');
	title('Pseudo velocity');
	setfigtempl;
	as = axis;
	axis([as(1) as(2) as(3) as(4)*1.05]);
	savepls(gcf,sprintf('twolink_pseudovelpath_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2(k)*100));
	
	figure
	plot(sm,a);
	xlabel('path coordinate (-)')
	ylabel('pseudo acceleration (1/s^2)');
	title('Pseudo acceleration');
	setfigtempl;
	as = axis;
	axis([as(1) as(2) as(3)*1.05 as(4)*1.05]);
	savepls(gcf,sprintf('twolink_pseudoaccpath_%s_%d_%d',func2str(pathfun),gamma1*100,gamma2(k)*100));
end	
	
