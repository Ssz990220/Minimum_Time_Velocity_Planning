function [q, qp, qpp] = sinpath(s)
%***************************************************************************
%  tag: Diederik Verscheure  di jun 12 18:06:25 CEST 2007  sinpath.m
%
%                           sinpath.m -  description
%                           ----------------------------
%    begin                : di juni 12 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Generates a simple sinusoidal path.
% 
% ***************************************************************************

q1 = (360/180*pi)*s;
q2 = (-131.3/180*pi)*ones(size(s));
q = [q1;q2];

q1p = (360/180*pi)*ones(size(s));
q2p = zeros(size(s));
qp = [q1p;q2p];

q1pp = zeros(size(s));
q2pp = zeros(size(s));
qpp = [q1pp;q2pp];

