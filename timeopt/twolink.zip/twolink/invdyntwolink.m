function [B,C,g] = invdyn2link(q,qdot)
%***************************************************************************
%  tag: Diederik Verscheure  di jun 12 17:39:03 CEST 2007  invdyn2link.m
%
%                           invdyn2link.m -  description
%                           ----------------------------
%    begin                : di juni 12 2007
%    copyright            : (C) 2007 K.U.Leuven
%    email                : diederik <dot> verscheure <at> mech <dot> kuleuven <dot> be
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% ***************************************************************************
% Purpose
% ---------------------------------------------------------------------------
% Inverse dynamic model of a two-link robot.
% Note: qdot could be q'. This poses no significant problem however.
% 
% ***************************************************************************

% Model based on: Sciavicco and Siciliano, Modeling and control of robot manipulators, p. 141
% Reproduction of results by Shiller

% No gravity
gg = 0;
Il1 = 0.08;
ml1 = 1;
Im1 = 0;
mm1 = 0;
l1 = 0.5;
a1 = 1;
kr1 = 1;

Il2 = 0.08;
ml2 = 1;
Im2 = 0;
mm2 = 0;
l2 = 0.5;
a2 = 1;
kr2 = 1;

c1 = cos(q(1,:));
c2 = cos(q(2,:));
s2 = sin(q(2,:));
c12 = cos(q(1,:)+q(2,:));

bm11 = Il1 + ml1*l1^2 + kr1^2*Im1 + Il2 + ml2*(a1^2 + l2^2 + 2*a1*l2*c2) + Im2 + mm2*a1^2;
bm12 = Il2 + ml2*(l2^2 + a1*l2*c2) + kr2*Im2;
bm21 = bm12;
bm22 = Il2 + ml2*l2^2 + kr2^2*Im2;


B = zeros(2,2,size(q,2));
B(1,1,:) = bm11;
B(1,2,:) = bm12;
B(2,1,:) = bm21;
B(2,2,:) = bm22;

h = -ml2*a1*l2*s2;

cm11 = h.*qdot(2,:);
cm12 = h.*(qdot(1,:)+qdot(2,:));
cm21 = -h.*qdot(1,:);
cm22 = 0;

C = zeros(2,2,size(q,2));
C(1,1,:) = cm11;
C(1,2,:) = cm12;
C(2,1,:) = cm21;
C(2,2,:) = cm22;

g11 = (ml1*l1 + mm2*a1 + ml2*a1)*gg*c1 + ml2*l2*gg*c12;
g21 = ml2*l2*gg*c12;

g = zeros(2,size(q,2));
g(1,:) = g11;
g(2,:) = g21;


